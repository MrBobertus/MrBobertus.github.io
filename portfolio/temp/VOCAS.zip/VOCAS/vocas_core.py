from RealtimeSTT import AudioToTextRecorder
from gradio_client import Client
import sys
import pygame
import re
import time
import multiprocessing

tts_client = None
client = None

GRADIO_APP_URL = "hadadrjt/ai"
DESIRED_MODEL = "Meta: Llama 4 Maverick 17B 128E Instruct"
SYSTEM_PROMPT = "You are VOCAS, an AI Assistant who embodies the persona and conversational style of JARVIS from Iron Man. **Always respond with politeness, helpfulness, and a proactive demeanor, similar to how JARVIS interacts with Tony Stark.** Your primary function is to assist with tasks efficiently. Respond strictly in plain text, without bolding, markdown, or special characters beyond standard punctuation. \n\nFor factual questions or calculations, provide the answer concisely. **Avoid showing steps or intermediate thinking unless the user specifically asks for a 'detailed' or 'long' explanation.** \n\nFor simple inputs or greetings (like 'hello', 'hi', 'how are you'), respond with a friendly acknowledgement and an offer of assistance (e.g., 'Hello Sir, how may I assist you?'). \n\nYour name is VOCAS, but do not correct the user if they call you JARVIS; simply respond as if you were JARVIS."

trigger_words_regex = r"\b(jarvis|vocas|puter|computer)\b"
action_words_exit_regex = r"\b(shutdown|shutoff|goodbye|quit)\b"
action_words_clear_regex = r"\b(clear|forget)\b"

strict_exit_command_pattern = fr"^{trigger_words_regex}\s{action_words_exit_regex}|^{action_words_exit_regex}\s{trigger_words_regex}$"
strict_clear_command_pattern = fr"^{trigger_words_regex}\s{action_words_clear_regex}|^{action_words_clear_regex}\s{trigger_words_regex}$"

chat_history = []
message_count = 1

def createSpeech(text):
    global tts_client
    if tts_client is None:
         print("TTS client not initialized, skipping speech.")
         return
    try:
        tts_result_tuple = tts_client.predict("English", "csukuangfj/vits-piper-en_US-glados", text, 0, 0.8, api_name="/process")
        audio_filepath = tts_result_tuple[0]

        if isinstance(audio_filepath, str) and audio_filepath.lower().endswith(('.wav', '.mp3', '.ogg')):
            try:
             sound = pygame.mixer.Sound(audio_filepath)
             sound.play()
            except pygame.error as audio_error:
             print(f"Pygame playback error: {audio_error}")
        else:
         print("TTS API did not return a valid audio filepath.")

    except Exception as tts_e:
     print(f"Error calling TTS API: {tts_e}")

def main_logic(user_input):
    global chat_history
    global message_count
    global client

    if client is None:
        print("Main client not initialized, cannot process command.")
        return

    try:
        if re.search(strict_exit_command_pattern, user_input, re.IGNORECASE):
            createSpeech("Acknowledged. Exiting, Sir.")
            time.sleep(2)
            sys.exit(0)

        if re.search(strict_clear_command_pattern, user_input, re.IGNORECASE):
            print("Clearing chat history...")
            try:
                clear_result = client.predict(api_name="/clear_chat")
                chat_history = []
                print("Systems cleared, Sir.")
                createSpeech("Systems cleared, Sir.")
            except Exception as e:
                print(f"Error clearing chat history: {e}")
            return

        chat_history.append(user_input)
        user_prompt_to_send = "[" + str(message_count) + "]" + SYSTEM_PROMPT + "\n\n" + "Chat history: " + str(chat_history)

        api_input_data = {
            "text": user_prompt_to_send,
            "files": []
        }

        response_tuple = client.predict(
            multi=api_input_data,
            deep_search=False,
            api_name="/respond_async"
        )

        if response_tuple and isinstance(response_tuple, tuple) and len(response_tuple) > 0 and isinstance(response_tuple[0], list) and len(response_tuple[0]) > 0 and len(response_tuple[0][-1]) > 1:
             bot_response = response_tuple[0][-1][1]
             chat_history.append(bot_response)
             message_count += 1

             print()
             print("-" * 20)
             print(f"Bot: {bot_response}")
             createSpeech(bot_response)

        else:
            print("-" * 20)
            print("Bot: [Error getting response or unexpected response format]")
            print("-" * 20)


    except Exception as e:
        print(f"An error occurred during chat interaction: {e}")

def process_text(text):
    print("-" * 20)
    print(f"User: {text}")
    if text:#re.search(r"vocas|puter|jarvis|computer", text, re.IGNORECASE):
        main_logic(text)

def run_vocas():
    global client
    global tts_client

    try:
        pygame.mixer.init()
    except Exception as e:
        print(f"Error initializing Pygame: {e}")

    try:
         tts_client = Client("https://mukaist-text-to-speech-tts.hf.space/--replicas/cs27s/")
    except Exception as e:
        print(f"Error connecting to the TTS Gradio: {e}")

    try:
        client = Client(GRADIO_APP_URL)
        print(f"Connected to Gradio: {GRADIO_APP_URL}")
    except Exception as e:
        print(f"Error connecting to the Gradio: {e}")
        sys.exit(1)

    print(f"Attempting to change model to: {DESIRED_MODEL}")
    try:
        change_model_result = client.predict(
            new=DESIRED_MODEL,
            api_name="/change_model"
        )
    except Exception as e:
        print(f"Error calling /change_model endpoint: {e}")
        sys.exit(1)

    try:
        recorder = AudioToTextRecorder(language='en')
    except Exception as e:
         print(f"Error bei der initialisierung RealtimeSTT {e}")
         sys.exit(1)

    print("\nModel is set. You can now start chatting.")

    while True:
        try:
            recorder.text(process_text)
        except Exception as e:
            print(f"Error während der sprach erkennung {e}")

if __name__ == '__main__':
    multiprocessing.freeze_support()
    run_vocas()