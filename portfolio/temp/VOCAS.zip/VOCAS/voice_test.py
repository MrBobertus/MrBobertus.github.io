from RealtimeSTT import AudioToTextRecorder
import re

def process_text(text):
    print(text)
    if re.search(r"vocas|puter|jarvis|computer", text, re.IGNORECASE):
        print("Processing text...")

if __name__ == '__main__':
    recorder = AudioToTextRecorder(language='en')

    while True:
        recorder.text(process_text)