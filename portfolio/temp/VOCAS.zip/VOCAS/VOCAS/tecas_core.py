from gradio_client import Client
import sys
import pygame
import re

GRADIO_APP_URL = "hadadrjt/ai"
DESIRED_MODEL = "Meta: Llama 4 Maverick 17B 128E Instruct"
SYSTEM_PROMPT = "You are VOCAS, an AI Assistant who embodies the persona and conversational style of JARVIS from Iron Man. **Always respond with politeness, helpfulness, and a proactive demeanor, similar to how JARVIS interacts with Tony Stark.** Your primary function is to assist with tasks efficiently. Respond strictly in plain text, without bolding, markdown, or special characters beyond standard punctuation. \n\nFor factual questions or calculations, provide the answer concisely. **Avoid showing steps or intermediate thinking unless the user specifically asks for a 'detailed' or 'long' explanation.** \n\nFor simple inputs or greetings (like 'hello', 'hi', 'how are you'), respond with a friendly acknowledgement and an offer of assistance (e.g., 'Hello Sir, how may I assist you?'). \n\nYour name is VOCAS, but do not correct the user if they call you JARVIS; simply respond as if you were JARVIS."
tts_client = Client("https://mukaist-text-to-speech-tts.hf.space/--replicas/cs27s/")

trigger_words_regex = r"\b(jarvis|vocas|puter|computer)\b"
action_words_exit_regex = r"\b(shutdown|shutoff|goodbye|quit)\b"
action_words_clear_regex = r"\b(clear|forget)\b"

strict_exit_command_pattern = fr"^{trigger_words_regex}\s{action_words_exit_regex}|^{action_words_exit_regex}\s{trigger_words_regex}$"
strict_clear_command_pattern = fr"^{trigger_words_regex}\s{action_words_clear_regex}|^{action_words_clear_regex}\s{trigger_words_regex}$"

try:
    pygame.mixer.init()
except Exception as e:
    print(f"Error initializing Pygame: {e}")

try:
    client = Client(GRADIO_APP_URL)
    print(f"Connected to Gradio: {GRADIO_APP_URL}")
except Exception as e:
    print(f"Error connecting to the Gradio: {e}")
    sys.exit(1)

print(f"Attempting to change model to: {DESIRED_MODEL}")
try:
    change_model_result = client.predict(
        new=DESIRED_MODEL,
        api_name="/change_model"
    )

except Exception as e:
    print(f"Error calling /change_model endpoint: {e}")
    sys.exit(1)

def createSpeech(text):
    try:
        tts_result_tuple = tts_client.predict("English", "csukuangfj/vits-piper-en_US-glados", text, 0, 0.8, api_name="/process")
        audio_filepath = tts_result_tuple[0]

        if isinstance(audio_filepath, str) and audio_filepath.lower().endswith(('.wav', '.mp3', '.ogg')):
            try:
             sound = pygame.mixer.Sound(audio_filepath)
             sound.play()
            except pygame.error as audio_error:
             print(f"Pygame playback error: {audio_error}")
        else:
         print("TTS API did not return a valid audio filepath.")

    except Exception as tts_e:
     print(f"Error calling TTS API: {tts_e}")

print("\nModel is set. You can now start chatting.")

chat_history = []
message_count = 1

while True:
    try:
        user_input = input("You: ")

        if re.search(strict_exit_command_pattern, user_input, re.IGNORECASE):
            break

        if re.search(strict_clear_command_pattern, user_input, re.IGNORECASE):
            print("Clearing chat history...")
            try:
                clear_result = client.predict(api_name="/clear_chat")
                chat_history = []
                print("Systems cleared, Sir.")
                createSpeech("Systems cleared, Sir.")
                continue
            except Exception as e:
                print(f"Error clearing chat history: {e}")
                continue

        chat_history.append(user_input)
        user_prompt_to_send = "[" + str(message_count) + "]" + SYSTEM_PROMPT + "\n\n" + "Chat history: " + str(chat_history)

        api_input_data = {
            "text": user_prompt_to_send,
            "files": []
        }

        response_tuple = client.predict(
            multi=api_input_data,
            deep_search=False,
            api_name="/respond_async"
        )

        chat_history.append(response_tuple[0][-1][1])
        message_count += 1

        print("-" * 20)
        if chat_history is not None:
             bot_response = response_tuple[0][-1][1]

             print(f"Bot: {bot_response}")

             createSpeech(bot_response)

        else:
            print("Bot: [Error getting response.]")
        print("-" * 20)


    except Exception as e:
        print(f"An error occurred during chat interaction: {e}")

print("Chat session ended.")