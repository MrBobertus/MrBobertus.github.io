let chatHistory = [];

document.addEventListener("DOMContentLoaded", function () {
  const inputElement = document.getElementById("input");
  const sendButton = document.getElementById("btn");
  const audioPlayer = document.getElementById("audioPlayer");

  sendButton.addEventListener("click", async function () {
    const textToSend = inputElement.value;

    if (textToSend.trim() === "") {
      alert("Bitte gib Text ein.");
      return;
    }

    chatHistory.push([textToSend, null]);

    inputElement.value = "";

    sendButton.disabled = true;
    inputElement.disabled = true;

    const serverEndpoint = "/process-prompt";

    try {
      const response = await fetch(serverEndpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userPrompt: textToSend,
          chatHistory: chatHistory,
        }),
      });

      if (!response.ok) {
        let errorMsg = `Server-Fehler: ${response.status} ${response.statusText}.`;
        try {
          const errorBody = await response.text();
          if (errorBody)
            errorMsg += ` Details: ${errorBody.substring(0, 200)}...`;
        } catch {}
        throw new Error(errorMsg);
      }

      const serverResponse = await response.json();

      if (serverResponse && serverResponse.updatedHistory) {
        chatHistory = serverResponse.updatedHistory; // Korrigiert: aktualisierte Historie zuweisen

        if (serverResponse.audioUrl) {
          audioPlayer.src = serverResponse.audioUrl;
          audioPlayer.load();
          audioPlayer.play();
        } else {
          alert("Antwort erhalten, aber keine Audio-URL.");
          if (audioPlayer) {
            audioPlayer.removeAttribute("src");
            audioPlayer.load();
          }
        }
      } else {
        alert("Server meldete Erfolg, aber unerwartete Antwortstruktur.");
        if (audioPlayer) {
          audioPlayer.removeAttribute("src");
          audioPlayer.load();
        }
      }
    } catch (error) {
      alert("Verarbeitung fehlgeschlagen: " + error.message);
      if (audioPlayer) {
        audioPlayer.removeAttribute("src");
        audioPlayer.load();
      }
    } finally {
      sendButton.disabled = false;
      inputElement.disabled = false;
      inputElement.focus();
    }
  });
});
