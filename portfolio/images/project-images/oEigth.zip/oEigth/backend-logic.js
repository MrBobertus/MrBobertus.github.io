import { Client } from "@gradio/client";

const TTS_SPACE_BASE_URL = "http://mukaist-text-to-speech-tts.hf.space/file=";
const AI_SPACE_URL = "hadadrjt/ai";
const TTS_SPACE_URL =
  "https://mukaist-text-to-speech-tts.hf.space/--replicas/cs27s/";

async function callGradioAI(newUserPrompt, oldHistory) {
  try {
    const client = await Client.connect(AI_SPACE_URL);
    const inputData = [
      {
        text: `You are an AI Assistant named oEigth. You are like JARVIS from Iron Man and will assist with every task that the user may have. Respond in plain text; do not use formatting like bolding or markdown or other special characters beyond standard punctuation.

${newUserPrompt}`,
        files: [],
      },
      oldHistory,
    ];
    const endpoint = "/api";
    const result = await client.predict(endpoint, inputData);
    const apiResultData = result.data;

    let updatedHistory = null;
    let lastAiMessageText = null;

    if (
      Array.isArray(apiResultData) &&
      apiResultData.length > 0 &&
      Array.isArray(apiResultData[0])
    ) {
      updatedHistory = apiResultData[0];
      if (updatedHistory.length > 0) {
        const lastPair = updatedHistory[updatedHistory.length - 1];
        if (Array.isArray(lastPair) && lastPair.length > 1) {
          lastAiMessageText = lastPair[1];
        }
      }
    } else {
      throw new Error("Unexpected response structure from AI API.");
    }

    return {
      updatedHistory: updatedHistory,
      lastAiMessageText: lastAiMessageText,
    };
  } catch (error) {
    throw new Error("Failed to call AI API: " + error.message);
  }
}

async function generateTTSAudio(inputText) {
  if (!inputText) {
    return null;
  }
  try {
    const app = await Client.connect(TTS_SPACE_URL);
    const targetLanguage = "English";
    const targetModel = "csukuangfj/vits-piper-en_US-glados";
    const speakerId = 0;
    const speed = 0.8;
    const endpoint = "/process";
    const inputData = [
      targetLanguage,
      targetModel,
      inputText,
      speakerId,
      speed,
    ];
    const result = await app.predict(endpoint, inputData);
    const ttsResultData = result.data;
    let audioLocalPath = null;

    if (
      Array.isArray(ttsResultData) &&
      ttsResultData.length > 0 &&
      ttsResultData[0] &&
      typeof ttsResultData[0].path === "string"
    ) {
      audioLocalPath = ttsResultData[0].path;
    } else {
      throw new Error("Unexpected response structure from TTS API.");
    }

    const audioUrl = TTS_SPACE_BASE_URL + audioLocalPath;
    return audioUrl;
  } catch (error) {
    throw new Error("Failed to generate TTS audio: " + error.message);
  }
}

export async function startLogic(userPrompt, oldHistory) {
  const client = await Client.connect("hadadrjt/ai");
  const result = await client.predict("/change_model", [
    "Meta: Llama 4 Maverick 17B 128E Instruct",
  ]);
  console.log(result.data);
  try {
    const aiResult = await callGradioAI(userPrompt, oldHistory);
    let audioUrl = null;
    if (aiResult.lastAiMessageText) {
      try {
        audioUrl = await generateTTSAudio(aiResult.lastAiMessageText);
      } catch (ttsError) {
        audioUrl = null;
      }
    }
    return {
      updatedHistory: aiResult.updatedHistory,
      audioUrl: audioUrl,
    };
  } catch (error) {
    throw new Error("Processing error in backend: " + error.message);
  }
}
