import express from "express";
import { startLogic } from "./backend-logic.js"; // Stelle sicher, dass startLogic die History-Parameter erwartet

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.static("public"));

app.post("/process-prompt", async (req, res) => {
  try {
    const userPrompt = req.body.userPrompt;
    const chatHistory = req.body.chatHistory; // Historie vom Client empfangen

    if (
      !userPrompt ||
      typeof userPrompt !== "string" ||
      userPrompt.trim() === ""
    ) {
      return res.status(400).json({ error: "Invalid prompt" });
    }

    // Historie an startLogic übergeben und das vollständige Ergebnis erhalten
    const processingResult = await startLogic(userPrompt, chatHistory);

    // Das vollständige Ergebnis (mit updatedHistory und audioUrl) zurücksenden
    res.status(200).json(processingResult);
  } catch (error) {
    console.error("Server-Fehler:", error); // Optional: Fehler auf dem Server loggen
    res.status(500).json({ error: "Processing failed" });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`); // Optional: Bestätigung, dass Server läuft
});
